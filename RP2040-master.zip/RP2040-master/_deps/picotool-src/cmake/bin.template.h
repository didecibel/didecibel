#include <stddef.h>

const unsigned char @C_NAME@[] = {@FILE_CONTENT@};

const size_t @C_NAME@_SIZE = @BIN_LENGTH@;
